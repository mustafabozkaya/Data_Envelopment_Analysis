
# Welcome to Optimization 101 for Data Scientists!

![Opti101Logo](Gurobi-Training-Opti-101.png)

- Resources for the first [hands-on modeling session](https://github.com/Gurobi/modeling-examples/tree/master/optimization101/Modeling_Session_1)

- Resources for the **second** [hands-on modeling session](https://github.com/Gurobi/modeling-examples/tree/master/optimization101/Modeling_Session_2)

- Resources for the **use case** [bike share modeling session](https://github.com/Gurobi/modeling-examples/tree/master/optimization101/Modeling_Session_2)
